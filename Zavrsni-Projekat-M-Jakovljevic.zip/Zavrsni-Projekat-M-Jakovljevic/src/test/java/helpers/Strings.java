package helpers;

public class Strings {
    public static final String uname = "Natalija";
    public static final String ulastename = "Jakovljevic";
    public static final String uemail = "marija@mail.com";
    public static final String pass = "55555";
    public static final String address = "Kosovska 2";
    public static final String addressSecond = "Kosovska 3";
    public static final String state = "India";
    public static final String ucity = "Beograd";
    public static final String uzipcode= "11060";
    public static final String number = "066023598";
    public static final String expectedMessageSignin = "ACCOUNT CREATED!";
    public static final String expectedMessageLogin = "ACCOUNT DELETED!";
    public static final String logInMessage = "Logged in as ";

    public static final String expectedMessageOrder = "ORDER PLACED!";
    public static final String cardNum = "123456";
    public static final String cvcNum = "121";
    public static final String monthNum = "8";
    public static final String yearNum = "2021";

}
