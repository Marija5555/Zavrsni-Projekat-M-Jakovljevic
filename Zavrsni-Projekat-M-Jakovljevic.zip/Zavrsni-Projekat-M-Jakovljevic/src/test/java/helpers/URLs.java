package helpers;

public class URLs {
    public static final String SIGNUPPAGE = "https://www.automationexercise.com/login";
    public static final String ACCOUNTCREATE = "https://www.automationexercise.com/account_created";
    public static final String HOMEPAGE = "https://www.automationexercise.com/";
    public static final String VIEWCART = "https://www.automationexercise.com/view_cart";
    public static final String PAYMENT = "https://www.automationexercise.com/payment";
    public static final String PRODUCT = "https://www.automationexercise.com/products";

}
